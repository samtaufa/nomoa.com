#!/usr/local/bin/python2.1
##################################################################################
#   Copyright (c) 2001 Samiuela LV Taufa
#   All rights reserved.
#   
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions
#   are met:
#   1. Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#   
#   THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
#   IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
#   OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
#   IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
#   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
#   NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
#   THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
##################################################################################
#
# Requires: Python The simplest installation is ActivePython from http://www.activestate.com (only tested on 2.1) 
#           Microsoft Excel (95 or higher tested)

import win32com.client, pythoncom		# Used for accessing Microsoft Excel
import os.path
import sys, re

# Constants from Excel
xlLeft  = -4131				# Left Aligned
xlRight = -4152				# Right Aligned
xlCenter = -4108			# Center Aligned

epsilon = 0.0000000000001		# ERROR MARGIN in Floating Point Calculations

	# Number Formatting
numFormatPercent  = re.compile("%$", re.I)
numFormatTwoDec   = re.compile("\.00(\D|$)", re.I)	# Two decimal values
numFormatCurrency = re.compile("^\$", re.I)	# Currency
numFormatDate     = re.compile("m[m/]", re.I) # Took a look at possible date formats, common stream is m (month or minute)

# StartUp Microsoft Excel using the win32com.client module
def initExcel(xlVisible = 0):
	""" Returns a tuple (xl instance, current state flag)
	Check to see if Excel is already Running.
	If Excel is already running, then connect to it, otherwise start it
	"""
	xlAlreadyRunning = 0
	try:
		xlObj = win32com.client.GetObject(None, "Excel.Application")
		xlAlreadyRunning = 1
	except pythoncom.com_error:
		try:
			xlObj = win32com.client.Dispatch("Excel.Application")
		except:
			sys.exit("Microsoft Excel Could Not Be Found. This program requires Microsoft Excel")
		
	if xlVisible:
		xlObj.Visible = 1
	else:
		xlObj.Visible = 0
	return xlObj, xlAlreadyRunning
	
def closeExcel(xlObj, xlAlreadyRunning):
	"""close Excel if Excel was not already running.
	"""
	if xlAlreadyRunning == 0:
		xlObj.Application.Quit()
	else:
		xlObj = None # release instance manually ?

def Caption(xlObj, strLiteral):
	"""Change the Application Caption for xlObj to the string in strLiteral
	"""
	xlObj.Caption = strLiteral
		
def OpenActivateFile (xlObj, docname, UpLinks = 0, RO= 1, Mru = 0):
	""" Open and set as the Active Workbook the Document docname.
	Parameters (xl Object, Full Path name, UpdateLinks ?, ReadOnly ?, Add to Most Recently Used list ?)
	"""
	xlObj.Workbooks.Open(docname, UpdateLinks=UpLinks, ReadOnly = RO, AddToMru=Mru)
	xlObj.Workbooks(os.path.basename(docname)	).Activate									# use the filename to be specific about which workbook is being analysed
		
def GetFormula( xlObj, Range ):
	""" Get the Formula in the Range given.
	"""
	return re.sub("\s","",xlObj.ActiveWorkbook.ActiveSheet.Range(Range).Formula)

def GetNumberFormat ( xlObj, Range):
	return str(xlObj.ActiveWorkbook.ActiveSheet.Range(Range).NumberFormat)

def isNumFormatPercent(xlObj, Range):
	if numFormatPercent.search(GetNumberFormat(xlObj, Range)):
		return 1
	return 0

def isNumFormatTwoDec(xlObj, Range):
	if numFormatTwoDec.search(GetNumberFormat(xlObj, Range)):
		return 1
	return 0

def isNumFormatCurrency(xlObj, Range):
	if numFormatCurrency.search(GetNumberFormat(xlObj, Range)):
		return 1
	return 0

def isNumFormatDate(xlObj, Range):
	if numFormatDate.search(GetNumberFormat(xlObj, Range)):
		return 1
	return 0

# .Value2: Use Value2 for getting values from MS Excel as this ignores formatting.
# - Financial / Currency formatting changes the returned value into a tuple, which
#   would increase the complexity of the analysis with no additional value
def GetValue2 (xlObj, Range):
	return xlObj.ActiveWorkbook.ActiveSheet.Range(Range).Value2
def isValue2(xlObj, Range, myValue):
	if GetValue2(xlObj, Range) - epsilon <= myValue <= GetValue2(xlObj, Range)+ epsilon:
		return 1
	return 0
def GetValue (xlObj, Range):
	return str(xlObj.ActiveWorkbook.ActiveSheet.Range(Range).Value)

def isBold (xlObj, Range):
	return xlObj.ActiveWorkbook.ActiveSheet.Range(Range).Font.Bold	

def isAlignedLeft(xlObj, Range):
	if xlObj.ActiveWorkbook.ActiveSheet.Range(Range).HorizontalAlignment == xlLeft:
		return 1
	else:
		return 0
		
def isAlignedRight(xlObj, Range):
	if xlObj.ActiveWorkbook.ActiveSheet.Range(Range).HorizontalAlignment == xlRight:
		return 1
	else:
		return 0
		
def isAlignedCenter(xlObj, Range):
	if xlObj.ActiveWorkbook.ActiveSheet.Range(Range).HorizontalAlignment == xlCenter:
		return 1
	else:
		return 0
		
def GetFontName (xlObj, Range):
	return xlObj.ActiveWorkbook.ActiveSheet.Range(Range).Font.Name

def GetFontSize (xlObj, Range):
	return xlObj.ActiveWorkbook.ActiveSheet.Range(Range).Font.Size	
	
def docInfo (xlObj, docname, Range):
	try:
		return xlObj.Workbooks(docname).BuiltinDocumentProperties(Range).Value	
	except:
		return "Not Available"

def docClose (xlObj, docname, Save=0):
	return xlObj.Workbooks(docname).Close(Save)		# CLOSE the workbook without (0) saving changes
		
def GetPaperSize (xlObj):
	return xlObj.ActiveWorkbook.ActiveSheet.PageSetup.PaperSize
def GetPaperOrientation (xlObj):
	return xlObj.ActiveWorkbook.ActiveSheet.PageSetup.Orientation
def GetColumnWidth (xlObj, column):	
	return xlObj.ActiveSheet.Columns(column).ColumnWidth
if __name__ == "__main__":
	pass

