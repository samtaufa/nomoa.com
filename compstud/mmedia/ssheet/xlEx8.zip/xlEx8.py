#!/usr/local/bin/python2.1
##################################################################################
#   Copyright (c) 2001 Samiuela LV Taufa
#   All rights reserved.
#   
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions
#   are met:
#   1. Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#   
#   THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
#   IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
#   OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
#   IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
#   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
#   NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
#   THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
##################################################################################
# Python Source Code for Marking Microsoft Excel Exercises.
#
# Requires: Python The simplest installation is ActivePython from http://www.activestate.com (only tested on 2.1) 
#              Microsoft Excel (95 or higher tested)
#         Modules:
#              dirWalk - should be available from the same location as this source code
import win32com.client		# Used for accessing Microsoft Excel
import re						# Used for String Analysis
import string					# Used for simple String Comparisons
import os						# Used for validating file existance
import os.path, pythoncom
import time
import sys
import dirWalk
import xl

# Constants from Excel

# Init Regular Expression (regex) String Analysis Variables
#  - we are using 'compile' to maximise performance on multiple 'search'es
#    this complicates the code, but not unnecessarily so.

epsilon = 0.0000000000001												# ERROR MARGIN in Floating Point Calculations
optlist = []

valueA1 = re.compile("disc|count.*\%",re.I)
valueA3 = re.compile("item.*n[ae]m[ae]",re.I)
valueA4 = re.compile("pen|tium.*166",re.I)
valueA5 = re.compile("pen|tium.*200",re.I)
valueA6 = re.compile("pen|tium.*233",re.I)
valueA7 = re.compile("pen|tium.*300",re.I)
valueA8 = re.compile("Total.*Av[ae]r[ae]g[ae]s",re.I)
valueB3 = re.compile("price",re.I)
valueC3 = re.compile("quantity",re.I)
valueD1 = re.compile("cust[oa]m[ae]r",re.I)
valueD3 = re.compile("discount",re.I)
valueE3 = re.compile("sub.*total",re.I)
	# Number Formatting
valuePercent  = re.compile("%$", re.I)
valueTwoDec   = re.compile ("\.00(\D|$)", re.I)	# Two decimal values
valueCurrency = re.compile ("^\$", re.I)	# Currency

	# Formulas
pattern = "^=(B4\*C4\*\$B\$1$)|(c4\*b4\*\$B\$1$)|(\$B\$1\*B4\*C4$)|"
pattern += "(\$B\$1\*B4\*C4$)|(\$B\$1\*c4\*b4$)|"
pattern += "(B4\*\$B\$1\*C4$)|(c4\*\$B\$1\*b4$)"
valueD4 = re.compile(pattern, re.I)

pattern, junk = re.subn( "4","5", pattern)
valueD5 = re.compile(pattern, re.I)

pattern, junk = re.subn("5","6", pattern)
valueD6 = re.compile(pattern, re.I)

pattern, junk = re.subn("6","7", pattern)
valueD7 = re.compile(pattern, re.I)

pattern = "^=(B7\*C7-D7$)|(c7\*b7-D7$)|(\(B7\*C7\)-D7$)|(\(c7\*b7\)-D7$)"
valueE7 = re.compile(pattern, re.I)
pattern, junk = re.subn("7","4", pattern)
valueE4 = re.compile(pattern, re.I) 
pattern, junk = re.subn("4","5", pattern)
valueE5 = re.compile(pattern, re.I) 
pattern, junk = re.subn("5","6", pattern)
valueE6 = re.compile(pattern, re.I) 

valueC8 = re.compile("^=average\(c3:c7\)$",re.I)

valueB9 = re.compile("^=max\(b[34]:b[78]\)",re.I)
valueE8 = re.compile("^=sum\(e[34]:e7\)",re.I)

# Process The File
def ProcessTheFile(xlApp, filepath, fh):	
	docname = os.path.basename(filepath)			# Get the filename, for use with Excel
	xl.Caption(xlApp, "[ " + docname + " ]")		# Change the caption for MSExcel to provide visual feedback
	marks = {}		# initialise the Dictionary for student marks
	uInfo={}		# initialise the Dictionary to store User Information
	print "\n"
	print "##  ===================================  ##"
	print "##  Processing File: " + docname
	print "##                                       ##"
	xl.OpenActivateFile(xlApp, filepath, 0, 1, 0) 	# Open the student submission in Excel	

	## Template
	print "Q1 ==>",
	marks['q1'] = 0
	if valueA1.search(xl.GetValue(xlApp,"a1")) and \
	   valueD1.search(xl.GetValue(xlApp,"d1")) and \
	   valueA3.search(xl.GetValue(xlApp,"a3")) and \
	   valueA4.search(xl.GetValue(xlApp,"a4")) and \
	   valueA5.search(xl.GetValue(xlApp,"a5")) and \
	   valueA6.search(xl.GetValue(xlApp,"a6")) and \
	   valueA7.search(xl.GetValue(xlApp,"a7")) and \
	   valueA8.search(xl.GetValue(xlApp,"a8")) and \
	   valueB3.search(xl.GetValue(xlApp,"b3")) and \
	   valueC3.search(xl.GetValue(xlApp,"c3")) and \
	   valueD3.search(xl.GetValue(xlApp,"d3")) and \
	   valueE3.search(xl.GetValue(xlApp,"e3")) :
		marks['q1'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Labels as Expected"
	print "A1:", xl.GetValue(xlApp, "A1"), 
	print "D3:", xl.GetValue(xlApp, "D3")
	for ncol in ["A","B","C","D","E"]:
	    print ncol+"3:", xl.GetValue(xlApp, ncol+"3"),
	print
	for ncol in range(4,9):
		print "A" + str(ncol) + ":" , xl.GetValue(xlApp, "A" + str(ncol))

	print "Q2 ==>",
	marks['q2a'] = marks['q2b'] = 0
	if xl.isAlignedCenter(xlApp, "a3,b3,c3,d3,e3"):
		marks ['q2a'] = 1
	if xl.isBold(xlApp, "a3,b3,c3,d3,e3"):
		marks['q2b'] = 1
	print marks['q2a'], marks['q2b']

	print "Q3 ==>",
	marks['q3a'] = marks['q3b'] = 0
	if xl.GetFontSize(xlApp, "d1") == 12.0:
		marks ['q3a'] = 1
	if xl.GetFontSize(xlApp, "e1") == 12.0:
		marks['q3b'] = 1
	print marks['q3a'], marks['q3b']

	print "Q4 ==>",
	marks['q4a'] = marks['q4b'] = 0
	if valuePercent.search(xl.GetNumberFormat(xlApp, "b1")):
		marks ['q4a'] = 1
	if valueTwoDec.search(xl.GetNumberFormat(xlApp, "b1")):
		marks['q4b'] = 1
	print marks['q4a'], marks['q4b']

	print "Q5 ==>",
	marks['q5a'] = marks['q5b'] = 0
	if valueCurrency.search(xl.GetNumberFormat(xlApp, "B4:B7, D4:D7,  E4:E7, B8, D8, E8")):
		marks ['q5a'] = 1
	if valueTwoDec.search(xl.GetNumberFormat(xlApp, "B4:B7, D4:D7,  E4:E7, B8, D8, E8")):
		marks['q5b'] = 1
	print marks['q5a'], marks['q5b']

# 38.2 - epsilon <= xl.GetValue2(xlApp, "B7") <=  38.2 + epsilon and \
	
	print "Q6 ==>",
	marks['q6'] = qcount = 0
	if 250 - epsilon <= xl.GetValue2(xlApp, "B4") <=  250 + epsilon:
		qcount += 1
	if 290 - epsilon <= xl.GetValue2(xlApp, "B5") <=  290 + epsilon:
		qcount += 1
	if 365 - epsilon <= xl.GetValue2(xlApp, "B6") <=  365 + epsilon:
		qcount += 1
	if 700 - epsilon <= xl.GetValue2(xlApp, "B7") <=  700 + epsilon:
		qcount += 1
	if 0.15 - epsilon <= xl.GetValue2(xlApp, "B1") <=  0.15 + epsilon:
		qcount += 1
	if 3 - epsilon <= xl.GetValue2(xlApp, "c4") <=  3 + epsilon:
		qcount += 1
	if 16 - epsilon <= xl.GetValue2(xlApp, "c5") <=  16 + epsilon:
		qcount += 1
	if 37 - epsilon <= xl.GetValue2(xlApp, "c6") <=  37 + epsilon:
		qcount += 1
	if 6 - epsilon <= xl.GetValue2(xlApp, "c7") <=  6 + epsilon:
		qcount += 1

	marks['q6'] = qcount / 3 # Integer Division should give us the value we want
	print marks['q6']

	print "Q7 ==>",
	marks['q7'] = 0
	if valueD4.search(xl.GetFormula(xlApp,"d4")):
		marks['q7'] = 3
		print "TRUE ",
	else:
		print "FALSE",
	print "b4*c4*$b$1",xl.GetFormula(xlApp,"d4")

	print "Q8 ==>",
	marks['q8'] = 0
	if valueE7.search(xl.GetFormula(xlApp,"e7")):
		marks['q8'] = 2
		print "TRUE ",
	else:
		print "FALSE",
	print "b7*c7-d7 :", xl.GetFormula(xlApp,"e7")

	print "Q9 ==>",
	marks['q9'] = 0
	if valueD5.search(xl.GetFormula(xlApp,"d5")) and \
	   valueD6.search(xl.GetFormula(xlApp,"d6")) and \
	   valueD7.search(xl.GetFormula(xlApp,"d7")):
		marks['q9'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Formulas filled down: ", xl.GetFormula(xlApp,"d5"), xl.GetFormula(xlApp,"d6"), xl.GetFormula(xlApp,"d7")

	print "Q10==>",
	marks['q10'] = 0
	if valueE4.search(xl.GetFormula(xlApp,"e4")) and \
	   valueE5.search(xl.GetFormula(xlApp,"e5")) and \
	   valueE6.search(xl.GetFormula(xlApp,"e6")):
		marks['q10'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Formulas filled down: ", xl.GetFormula(xlApp,"e4"),xl.GetFormula(xlApp,"e5"),xl.GetFormula(xlApp,"e6")

	print "Q11==>",
	marks['q11'] = 0
	if valueC8.search(xl.GetFormula(xlApp,"c8")):
		marks['q11'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "average(c3:c7)  :", xl.GetFormula(xlApp,"c8")

	print "Q12==>",
	marks['q12'] = 0
	if valueB9.search(xl.GetFormula(xlApp,"b9")):
		marks['q12'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "max(b3:b8) :",xl.GetFormula(xlApp,"b9")

	print "Q13==>",
	marks['q13'] = 0
	if valueE8.search(xl.GetFormula(xlApp,"e8")):
		marks['q13'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "sum(e4:e7) :",xl.GetFormula(xlApp,"e8")
	
	studscore = 0
	for key in marks.keys():
		studscore = studscore + marks[key]

	# Basic Document Information Extracted from the File:
	# - this information is recorded along with the OS information

	uInfo['Author']         = xl.docInfo (xlApp, docname, 'Author') 
	uInfo['Last Author']    = xl.docInfo (xlApp, docname, 'Last Author')
	uInfo['Creation Date']  = xl.docInfo (xlApp, docname, 'Creation Date')
	uInfo['Last Save Time'] = xl.docInfo (xlApp, docname, 'Last Save Time')
	uInfo['os File Time']	= time.asctime(time.localtime(os.path.getmtime(filepath)))
	xl.docClose (xlApp, docname, 0)

	insertLog(fh, marks, uInfo, filepath)	
	
	print ""
	print "______________________________"
	print "Student Score is: ",
	print studscore
	print "------------------------------"

def insertLog(fh, marks, uInfo, filepath):
	#
	# OutPut a summary of the information gathered above, into a data file for easy extraction
	# into a spreadsheet or database
	# -- redirect stdout (so I can use the print command rather than write)
	#    doing this lets the more complex 'print' provide the conversion of expressoin
	#    to a string for output, otherwise I would have to write a routine for converting
	#    the output data to 'string' before I could use write.
	cons_stdout = sys.__stdout__
	sys.stdout = fh
	sep = '\t'
	print marks['q1'], sep,marks['q2a'], sep,marks['q2b'], sep,marks['q3a'],sep,marks['q3b'],
	print sep,marks['q4a'],sep,marks['q4b'],sep,marks['q5a'],sep,marks['q5b'],
	print sep,marks['q6'],sep,marks['q7'],sep,marks['q8'],sep,marks['q9'],sep,marks['q10'],sep,marks['q11'],
	print sep,marks['q12'],sep,marks['q13'],
	print sep,os.path.basename(filepath), sep, os.path.basename(os.path.dirname(filepath)),
	print sep,uInfo['Creation Date'], sep, uInfo['Last Save Time'],  sep, uInfo['os File Time'],
	print sep,uInfo['Author'], sep,uInfo['Last Author']

	# -- return the stdout to the console	
	sys.stdout = cons_stdout	
def initLogFile(outfile):
	fh = open(outfile,'w')
	sep = "\t"
	fh.write('q1\tq2a\tq2b\tq3a\tq3b')
	fh.write('\tq4a\tq4b\tq5a\tq5b')
	fh.write('\tq6\tq7\tq8\tq9\tq10\tq11')
	fh.write('\tq12\tq13')
	fh.write('\tfilename\tdirectory')
	fh.write('\txl Creation Date\txl Last Save Time\tos File Time\txl Author\txl Last Author')
	fh.write('\n')
	return fh
		
def cmdlineoptions():
	import getopt
	try:
		optlist, args = getopt.getopt(sys.argv[1:], 'f:d:p:o:')
	except getopt.GetoptError:
#    except:
		# print help information and exit:
		usage()
		sys.exit(2)
		
	if optlist==[]:
		usage()
		sys.exit(2)
		
	return optlist

def usage():
	progname = os.path.basename(sys.argv[0])

	print """
	Usage: %s [ -d directory [-p pattern] | -f filename ] [ -o outfile ]
	
	-d directory  the name of the directory to be analysed (including subdirectories)
	                  default(.)
	-p pattern    when used with -d specifies the file pattern to analyse
	                  default(*.xl?;*.wk?)
	-f filename    the name of the file to be analysed
	-o outfile      output file for recording summary information (good for use in data-analysis)
	
	example: %s -d submissions -p *.xl?;*.wk?
	         %s -d submissions
	         %s -f charlie.xls
	         %s -d submissions -o %s-summary.txt > %s-detailed.txt

	%s is a program developed to analyse (mark) student submissions for
	spreadsheet exercise Exercise 8 from http://www.tongatapu.net.to/compstud/
	This program requires Microsoft Excel and may be a useful tutorial 
	in getting data from Microsoft Excel using Python
	""" % (progname, progname, progname, progname, progname, progname, progname, progname)
	
def cmdlineprocess(optlist):
	searchdir = None
	filename = None
	dirpattern = "*.xl?;*.wk?"
	progname, extension = os.path.splitext(sys.argv[0])
	outfile = os.path.basename(progname) + ".txt"
	for optitem in optlist:
		if optitem[1][1:1] == "-":
			usage()
			sys.exit(2)
		elif optitem[0] == "-d":
			searchdir = 1
			if optitem[1] <> "":
				dir2search = optitem[1]
			else:
				dir2search = "."
		elif optitem[0] == "-p":
			if optitem[1] <> "":
				dirpattern = optitem[1]
			else:
				usage()
				sys.exit(2)
		elif optitem[0] == "-f":
			if optitem[1] <> "":
				filename = optitem[1]
			else:
				usage()
				sys.exit(2)
		elif optitem[0] == "-o":
			if optitem[1]<>"":
				outfile = optitem[1]
		else:
			pass

	xlApp, xlAlreadyRunning = xl.initExcel(1)
	fh = initLogFile(outfile)
	if searchdir:
		files = dirWalk.dirWalk(os.path.abspath(dir2search),1,dirpattern,1)
		for file in files:
			ProcessTheFile(xlApp, file, fh)
	elif filename:
		ProcessTheFile(xlApp, os.path.abspath(filename), fh)
	else:
		pass
		# usage()
		# sys.exit(2)
	xl.closeExcel(xlApp, xlAlreadyRunning)

# Open the file where data log of reports will be sent
# Format: Tab-delimited
#			Identifying Columns 1st,
#			Marks Details 2nd
#			Document Information 3rd

if __name__ == "__main__":
	optlist = cmdlineoptions()
	cmdlineprocess(optlist)

