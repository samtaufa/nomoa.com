#!/usr/local/bin/python2.1
##################################################################################
#   Copyright (c) 2001 Samiuela LV Taufa
#   All rights reserved.
#   
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions
#   are met:
#   1. Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#   
#   THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
#   IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
#   OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
#   IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
#   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
#   NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
#   THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
##################################################################################
# Python Source Code for Marking Microsoft Excel Exercises.
#
# Requires: Python The simplest installation is ActivePython from http://www.activestate.com (only tested on 2.1) 
#              Microsoft Excel (95 or higher tested)
#         Modules:
#              dirWalk - should be available from the same location as this source code
import win32com.client		# Used for accessing Microsoft Excel
import re						# Used for String Analysis
import string					# Used for simple String Comparisons
import os						# Used for validating file existance
import os.path, pythoncom
import time
import sys
import dirWalk
import xl

optlist = []

# Init Regular Expression (regex) String Analysis Variables
#  - we are using 'compile' to maximise performance on multiple 'search'es
#    this complicates the code, but not unnecessarily so.

valueA1 = re.compile('high-tech company', re.I)
valueA1not = re.compile('\[your|name\]', re.I)
valueA2not = re.compile('\[school|name\]', re.I)
valueA4 = re.compile('tax|rate', re.I)
valueA6 = re.compile('n[ea]m[ae]', re.I)
valueA7 = re.compile('alisi|tonga', re.I)
valueA8 = re.compile('semisi|fonua', re.I)
valueA9 = re.compile('kolini|houma', re.I)
valueA10= re.compile('lisa|nuku', re.I)
valueA11= re.compile("lisiate|ma'afu", re.I)
valueA13= re.compile('total', re.I)

valueB6 = re.compile('hour|work', re.I)
valueC6 = re.compile('pay|code', re.I)
valueD6 = re.compile('hour|rate', re.I)
valueE6 = re.compile('gr[ao]ss.*p[ae]y', re.I)
valueF6 = re.compile('tax|due', re.I)
valueG6 = re.compile('net|pay', re.I)

	# Formulas
pattern = '^=(b7\*d7)|(d7\*b7)|(\(b7\*d7\))|(\(d7\*b7\))$'
valueE7 = re.compile(pattern, re.I)
pattern, junk = re.subn("7","8",pattern)
valueE8 = re.compile(pattern, re.I)
pattern, junk = re.subn("8","9",pattern)
valueE9 = re.compile(pattern, re.I)
pattern, junk = re.subn("9","10",pattern)
valueE10 = re.compile(pattern, re.I)
pattern, junk = re.subn("10","11",pattern)
valueE11 = re.compile(pattern, re.I)

pattern = '^=(e7\*\$b\$4)|(\$b\$4\*e7)|(\(e7\*\$b\$4\))|(\(\$b\$4\*e7\))$'
valueF7 = re.compile(pattern, re.I)
pattern, junk = re.subn("7","8", pattern)
valueF8 = re.compile(pattern, re.I)
pattern, junk = re.subn("8","9", pattern)
valueF9 = re.compile(pattern, re.I)
pattern, junk = re.subn("9","10", pattern)
valueF10 = re.compile(pattern, re.I)
pattern, junk = re.subn("10","11", pattern)
valueF11 = re.compile(pattern, re.I)

pattern ='^=(e7-f7)|(\(e7-f7\))$'
valueG7 = re.compile(pattern, re.I)
pattern, junk = re.subn("7","8", pattern)
valueG8 = re.compile(pattern, re.I)
pattern, junk = re.subn("8","9", pattern)
valueG9 = re.compile(pattern, re.I)
pattern, junk = re.subn("9","10", pattern)
valueG10 = re.compile(pattern, re.I)
pattern, junk = re.subn("10","11", pattern)
valueG11 = re.compile(pattern, re.I)

pattern = '^=sum\(e[67]:e1[12]\)$'
valueE13 = re.compile(pattern, re.I)
pattern, junk = re.subn("e","f", pattern)
valueF13 = re.compile(pattern, re.I)
pattern, junk = re.subn("f","g", pattern)
valueG13 = re.compile(pattern, re.I)

valueChartTitle = re.compile ('hour.*worked summary',re.I)

# Process The File
def ProcessTheFile(xlApp, filepath, fh):	
	docname = os.path.basename(filepath)			# Get the filename, for use with Excel
	xl.Caption(xlApp, "[ " + docname + " ]")		# Change the caption for MSExcel to provide visual feedback
	marks = {}		# initialise the Dictionary for student marks
	uInfo={}		# initialise the Dictionary to store User Information
	print "\n"
	print "##  ===================================  ##"
	print "##  Processing File: " + docname
	print "##                                       ##"
	xl.OpenActivateFile(xlApp, filepath, 0, 1, 0) 	# Open the student submission in Excel	

	## Template
	print "Q1 ==>",
	marks['q1'] = 0
	if xl.GetFontSize(xlApp,"a1:g15")==12:
		marks['q1'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Expected 12; Got",xl.GetFontSize(xlApp,"a1:g15")
	
	print "Q2 ==>",
	if valueA1.search(xl.GetValue(xlApp,"a1")) and \
	   not valueA1not.search(xl.GetValue(xlApp,"a1")) and \
		not valueA2not.search(xl.GetValue(xlApp,"a2")) and \
		valueA4.search(xl.GetValue(xlApp,"a4")) and \
		valueA6.search(xl.GetValue(xlApp,"a6")) and \
		valueA7.search(xl.GetValue(xlApp,"a7")) and \
		valueA8.search(xl.GetValue(xlApp,"a8")) and \
		valueA9.search(xl.GetValue(xlApp,"a9")) and \
		valueA10.search(xl.GetValue(xlApp,"a10")) and \
		valueA11.search(xl.GetValue(xlApp,"a11")) and \
		valueA13.search(xl.GetValue(xlApp,"a13")) and \
		\
		valueB6.search(xl.GetValue(xlApp,"b6")) and \
		valueC6.search(xl.GetValue(xlApp,"c6")) and \
		valueD6.search(xl.GetValue(xlApp,"d6")) and \
		valueE6.search(xl.GetValue(xlApp,"e6")) and \
		valueF6.search(xl.GetValue(xlApp,"f6")) and \
		valueG6.search(xl.GetValue(xlApp,"g6")) and \
		\
		xl.isValue2(xlApp, "b7", 22) and \
		xl.isValue2(xlApp, "b8", 15) and \
		xl.isValue2(xlApp, "b9", 18) and \
		xl.isValue2(xlApp, "b10", 12) and \
		xl.isValue2(xlApp, "b11", 11) and \
		\
		xl.GetValue(xlApp, "c7") == "B" and \
		xl.GetValue(xlApp, "c8") == "C" and \
		xl.GetValue(xlApp, "c9") == "A" and \
		xl.GetValue(xlApp, "c10") == "C" and \
		xl.GetValue(xlApp, "c11") == "A" and \
		\
		valueA13.search(xl.GetValue(xlApp,"a13"))  :
		marks['q2'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print
	print "A1:",xl.GetValue(xlApp, "a1")
	print "A2:",xl.GetValue(xlApp, "a2")
	print "A4:",xl.GetValue(xlApp, "a4")

	for ncol in ['a','b','c','d','e','f','g']:
		print ncol + "6:", xl.GetValue(xlApp,ncol+"6"),

	print
	for nrow in ['7','8','9','10','11']:
		for ncol in ['a','b','c']:
			print ncol+nrow+":", xl.GetValue(xlApp,ncol+nrow),
		print
	print "a13", xl.GetValue(xlApp,"a13")

	print "Q3 ==>",
	marks['q3'] = 0
	# Column Spacing defaults to 8.43, so we are measuring differences from that standard.
	colStandard = 8.43
	if colStandard + 24 < xl.GetColumnWidth(xlApp, 'a')< colStandard + 29 and \
	   colStandard + 10 < xl.GetColumnWidth(xlApp, 'b')< colStandard + 15  and \
	   colStandard + 2 < xl.GetColumnWidth(xlApp, 'c') < colStandard + 7  and \
	   colStandard + 6 < xl.GetColumnWidth(xlApp, 'd') < colStandard + 11  and \
	   colStandard + 4 < xl.GetColumnWidth(xlApp, 'e') < colStandard + 9  and \
	   colStandard + .9 < xl.GetColumnWidth(xlApp, 'f')< colStandard + 6 and \
	   colStandard + 4 < xl.GetColumnWidth(xlApp, 'g') < colStandard + 9 :
		marks['q3'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Column Widths:",
	for column in ['a','b','c','d','e','f','g']:
		print column+":",xl.GetColumnWidth(xlApp, column),
	print
	print "Q4 ==>",
	marks['q4'] = 0
	if valueA1.search(xl.GetValue(xlApp,"a1")):
		marks['q4'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Name:", xl.GetValue(xlApp,'a1')

	print "Q5 ==>",
	marks['q5'] = 0
	if not valueA2not.search(xl.GetValue(xlApp,'a2')):
		marks['q5'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "School:", xl.GetValue(xlApp,'a2')
	
	print "Q6 ==>",
	marks['q6'] = 0
	if xl.isValue2(xlApp, 'd7', 18) and \
	   xl.isValue2(xlApp, 'd8', 21) and \
	   xl.isValue2(xlApp, 'd9', 15) and \
	   xl.isValue2(xlApp, 'd10', 21) and \
	   xl.isValue2(xlApp, 'd11', 15) :
		marks['q6'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Expected (18,21,15,21,15) Got:",xl.GetValue2(xlApp,'d7'),xl.GetValue2(xlApp,'d8'),xl.GetValue2(xlApp,'d9'),xl.GetValue2(xlApp,'d10'),xl.GetValue2(xlApp,'d11')
	
	print "Q7 ==>",
	marks['q7'] = 0
	if xl.GetValue2(xlApp, 'a3') == None and \
	   xl.GetValue2(xlApp, 'b3') == None and \
	   xl.GetValue2(xlApp, 'c3') == None and \
	   xl.GetValue2(xlApp, 'd3') == None and \
	   xl.GetValue2(xlApp, 'e3') == None and \
	   xl.GetValue2(xlApp, 'f3') == None:
		marks['q7'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print
	
	print "Q8 ==>",
	marks['q8'] = 1
	print "AWARDED. Still working on a test for this.", 
	print "Date",xl.GetValue2(xlApp,'g3'), xl.GetFormula(xlApp,'g3')
	
	print "Q9 ==>",
	marks['q9'] = 0
	if xl.isNumFormatDate(xlApp, 'g3'):
		marks['q9'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Date Format:", xl.GetNumberFormat(xlApp,'g3')
	print "Q10==>",
	marks['q10'] = 0
	if xl.isValue2(xlApp, 'b4', 0.2):
		marks['q10'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "expected: 0.2, Got:",xl.GetValue2(xlApp,'b4')
	
	print "Q11==>",
	marks['q11'] = 0
	if xl.isNumFormatPercent(xlApp,'b4'):
		marks['q11'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Expected %, Got:", xl.GetNumberFormat(xlApp,'b4')
	
	print "Q12==>",
	marks['q12a'] = marks['q12b'] = 0
	if valueE7.search(xl.GetFormula(xlApp,'e7')):
		marks['q12a'] = 2
	
	if valueE8.search(xl.GetFormula(xlApp,'e8')) and \
	   valueE9.search(xl.GetFormula(xlApp,'e9')) and \
	   valueE10.search(xl.GetFormula(xlApp,'e10')) and \
	   valueE11.search(xl.GetFormula(xlApp,'e11')) :
		marks['q12b'] = 1
	print marks['q12a'], marks['q12b'], 'Expected: b7*d7 Got:',
	for column in ['7','8','9','10','11']:
		print 'e'+column+':', xl.GetFormula(xlApp,'e'+column),
	print

	print "Q13==>",
	marks['q13a'] = marks['q13b'] = 0
	if valueF7.search(xl.GetFormula(xlApp,'f7')):
		marks['q13a'] = 2

	if valueF8.search(xl.GetFormula(xlApp,'f8')) and \
	   valueF9.search(xl.GetFormula(xlApp,'f9')) and \
	   valueF10.search(xl.GetFormula(xlApp,'f10')) and \
	   valueF11.search(xl.GetFormula(xlApp,'f11')):
		marks['q13b'] = 1
	print marks['q13a'], marks['q13b'], 'Expected: E7*$B$4 Got:',
	for column in ['7','8','9','10','11']:
		print 'f'+column+':', xl.GetFormula(xlApp,'f'+column),
	print
	
	print "Q14==>",
	marks['q14a'] = marks['q14b'] = 0
	if valueG7.search(xl.GetFormula(xlApp,'G7')):
		marks['q14a'] = 1

	if valueG8.search(xl.GetFormula(xlApp,'G8')) and \
	   valueG9.search(xl.GetFormula(xlApp,'G9')) and \
	   valueG10.search(xl.GetFormula(xlApp,'G10')) and \
	   valueG11.search(xl.GetFormula(xlApp,'G11')):
		marks['q14b'] = 1
	print marks['q14a'], marks['q14b'], 'Expected: E7-F7 Got:',
	for column in ['7','8','9','10','11']:
		print 'G'+column+':', xl.GetFormula(xlApp,'G'+column),
	print
	
	print "Q15==>",
	marks['q15a'] = marks['q15b'] = 0
	if valueE13.search(xl.GetFormula(xlApp,'E13')):
		marks['q15a'] = 1
	if valueF13.search(xl.GetFormula(xlApp,'F13')) and \
	   valueG13.search(xl.GetFormula(xlApp,'G13')):
		marks['q15b'] = 1
	print marks['q15a'], marks['q15b'], 'Expected: =sum(e7:e11) Got:',
	for column in ['e','f','g']:
		print column +'13:', xl.GetFormula(xlApp,column+'13'),
	print

	print "Q16==>",
	marks['q16'] = 0
	if xl.isNumFormatCurrency(xlApp,'e7:g13') and \
	   xl.isNumFormatTwoDec(xlApp, 'e7:g13'):
		marks['q16'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Expected: Currency & Two Decimal Places, Got:", xl.GetNumberFormat(xlApp, 'e7:g13')

	print "Q17==>",
	marks['q17a'] = marks['q17b'] = marks['q17c'] = ChartType = 0
	ChartTitle = ""
	if xlApp.ActiveWorkbook.Charts.Count >= 1:  # A Chart exists
		for chartnum in range(xlApp.ActiveWorkbook.Charts.Count):
			ChartTitle = xlApp.ActiveWorkbook.Charts(chartnum+1).ChartTitle.Caption
			ChartType =  xlApp.ActiveWorkbook.Charts(1).ChartType			
			if valueChartTitle.search(xlApp.ActiveWorkbook.Charts(chartnum+1).ChartTitle.Caption):
				marks['q17c'] = 1
			if  xlApp.ActiveWorkbook.Charts(1).ChartType == 5:
				marks['q17b'] = 1
			if xlApp.ActiveWorkbook.Charts(1).Parent.Name == docname:
				marks['q17a'] = 1
	print marks['q17a'], marks['q17b'], marks['q17c'], 'Title:'+ChartTitle,'Type:',ChartType


	print "Q18==>",
	marks['q18a'] = marks['q18b'] = 0  # xlOrientation = 2, xlPaperLegal = 5
	if xl.GetPaperSize(xlApp) == 5:
		marks['q18b'] = 1
	if xl.GetPaperOrientation(xlApp) == 2:
		marks['q18a'] = 1
	print marks['q18a'], marks['q18b'], "Expected: 2, 5; Got:", xl.GetPaperOrientation(xlApp), xl.GetPaperSize(xlApp)
		
	print "Q19==>",
	marks['q19'] = 1
	print "AWARDED. Assumption that Spreadsheet exists."
	
	studscore = 0
	for key in marks.keys():
		studscore = studscore + marks[key]

	# Basic Document Information Extracted from the File:
	# - this information is recorded along with the OS information

	uInfo['Author']         = xl.docInfo (xlApp, docname, 'Author') 
	uInfo['Last Author']    = xl.docInfo (xlApp, docname, 'Last Author')
	uInfo['Creation Date']  = xl.docInfo (xlApp, docname, 'Creation Date')
	uInfo['Last Save Time'] = xl.docInfo (xlApp, docname, 'Last Save Time')
	uInfo['os File Time']	= time.asctime(time.localtime(os.path.getmtime(filepath)))
	xl.docClose (xlApp, docname, 0)

	insertLog(fh, marks, uInfo, filepath)	
	
	print ""
	print "______________________________"
	print "Student Score is: ",
	print studscore
	print "------------------------------"

def insertLog(fh, marks, uInfo, filepath):
	#
	# OutPut a summary of the information gathered above, into a data file for easy extraction
	# into a spreadsheet or database
	# -- redirect stdout (so I can use the print command rather than write)
	#    doing this lets the more complex 'print' provide the conversion of expressoin
	#    to a string for output, otherwise I would have to write a routine for converting
	#    the output data to 'string' before I could use write.
	cons_stdout = sys.__stdout__
	sys.stdout = fh
	sep = '\t'
#	print marks['q1'], sep,marks['q2a'], sep,marks['q2b'], sep,marks['q3a'],sep,marks['q3b'],
#	print sep,marks['q4a'],sep,marks['q4b'],sep,marks['q5a'],sep,marks['q5b'],
#	print sep,marks['q6'],sep,marks['q7'],sep,marks['q8'],sep,marks['q9'],sep,marks['q10'],sep,marks['q11'],
#	print sep,marks['q12'],sep,marks['q13'],
	print sep,os.path.basename(filepath), sep, os.path.basename(os.path.dirname(filepath)),
	print sep,uInfo['Creation Date'], sep, uInfo['Last Save Time'],  sep, uInfo['os File Time'],
	print sep,uInfo['Author'], sep,uInfo['Last Author']

	# -- return the stdout to the console	
	sys.stdout = cons_stdout	
def initLogFile(outfile):
	fh = open(outfile,'w')
	sep = "\t"
	fh.write('q1\tq2a\tq2b\tq3a\tq3b')
	fh.write('\tq4a\tq4b\tq5a\tq5b')
	fh.write('\tq6\tq7\tq8\tq9\tq10\tq11')
	fh.write('\tq12\tq13')
	fh.write('\tfilename\tdirectory')
	fh.write('\txl Creation Date\txl Last Save Time\tos File Time\txl Author\txl Last Author')
	fh.write('\n')
	return fh
		
def cmdlineoptions():
	import getopt
	try:
		optlist, args = getopt.getopt(sys.argv[1:], 'f:d:p:o:')
	except getopt.GetoptError:
#    except:
		# print help information and exit:
		usage()
		sys.exit(2)
		
	if optlist==[]:
		usage()
		sys.exit(2)
		
	return optlist

def usage():
	progname = os.path.basename(sys.argv[0])

	print """
	Usage: %s [ -d directory [-p pattern] | -f filename ] [ -o outfile ]
	
	-d directory  the name of the directory to be analysed (including subdirectories)
	                  default(.)
	-p pattern    when used with -d specifies the file pattern to analyse
	                  default(*.xl?;*.wk?)
	-f filename    the name of the file to be analysed
	-o outfile      output file for recording summary information (good for use in data-analysis)
	
	example: %s -d submissions -p *.xl?;*.wk?
	         %s -d submissions
	         %s -f charlie.xls
	         %s -d submissions -o %s-summary.txt > %s-detailed.txt

	%s is a program developed to analyse (mark) student submissions for
	spreadsheet exercise Exercise 9 from http://www.tongatapu.net.to/compstud/
	This program requires Microsoft Excel and may be a useful tutorial 
	in getting data from Microsoft Excel using Python
	""" % (progname, progname, progname, progname, progname, progname, progname, progname)
	
def cmdlineprocess(optlist):
	searchdir = None
	filename = None
	dirpattern = "*.xl?;*.wk?"
	progname, extension = os.path.splitext(sys.argv[0])
	outfile = os.path.basename(progname) + ".txt"
	for optitem in optlist:
		if optitem[1][1:1] == "-":
			usage()
			sys.exit(2)
		elif optitem[0] == "-d":
			searchdir = 1
			if optitem[1] <> "":
				dir2search = optitem[1]
			else:
				dir2search = "."
		elif optitem[0] == "-p":
			if optitem[1] <> "":
				dirpattern = optitem[1]
			else:
				usage()
				sys.exit(2)
		elif optitem[0] == "-f":
			if optitem[1] <> "":
				filename = optitem[1]
			else:
				usage()
				sys.exit(2)
		elif optitem[0] == "-o":
			if optitem[1]<>"":
				outfile = optitem[1]
		else:
			pass

	xlApp, xlAlreadyRunning = xl.initExcel(1)
	fh = initLogFile(outfile)
	if searchdir:
		files = dirWalk.dirWalk(os.path.abspath(dir2search),1,dirpattern,1)
		for file in files:
			ProcessTheFile(xlApp, file, fh)
	elif filename:
		ProcessTheFile(xlApp, os.path.abspath(filename), fh)
	else:
		pass
		# usage()
		# sys.exit(2)
	xl.closeExcel(xlApp, xlAlreadyRunning)

# Open the file where data log of reports will be sent
# Format: Tab-delimited
#			Identifying Columns 1st,
#			Marks Details 2nd
#			Document Information 3rd

if __name__ == "__main__":
	optlist = cmdlineoptions()
	cmdlineprocess(optlist)

