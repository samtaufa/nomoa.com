#!/usr/local/bin/python2.1
# Python Source Code for Marking Microsoft Excel Exercises.
#
# Requires: Python The simplest installation is ActivePython from http://www.activestate.com (only tested on 2.1) 
#              Microsoft Excel (95 or higher tested)
#         Modules:
#              dirWalk - should be available from the same location as this source code
import win32com.client		# Used for accessing Microsoft Excel
import re						# Used for String Analysis
import string					# Used for simple String Comparisons
import os						# Used for validating file existance
import os.path, pythoncom
import time
import sys
import dirWalk
import xl

# Constants from Excel

# Init Regular Expression (regex) String Analysis Variables
#  - we are using 'compile' to maximise performance on multiple 'search'es
#    this complicates the code, but not unnecessarily so.
q2_str   = re.compile ("[a-z]{2,}", re.I)								# 2 or more Letters
q2a_str  = re.compile("\d{3,}",re.I)									# 3 or more digits
			# QUESTION -- what about misreads? (CAT or ID# or ID)
q3_str    = re.compile ("\.0|General|[a-z]|\%|@|\\|/|\?",re.I) 				#NOT any of these
q5a1_str = re.compile ("my|statistics|project", re.I)					#
q5e3_str = re.compile ("fact[ao]r",re.I)								# spelling variance
q5a5_str = re.compile ("n(am|m)e",re.I)									# spelling variance
q5b5_str = re.compile ("neck|nck",re.I)									# spelling variance
q5c5_str = re.compile ("arm",re.I)										# no spelling variance
q5d5_str = re.compile ("w(ei|ie)(gh|hg)t",re.I)							# spelling variance
q5e5_str = re.compile ("pay|ment",re.I)									# spelling variance
q5f5_str = re.compile ("n[ea]ck.*fact[oa]r",re.I)						# spelling variance
q5g5_str = re.compile ("diff|erence",re.I)								# spelling variance
q10a7_str = re.compile("ana",re.I)
q10a8_str = re.compile("lopeti",re.I)
q10a9_str = re.compile("mele",re.I)
q10a10_str = re.compile("peni",re.I)
q11_str = re.compile ("\.0(\D|$)",re.I)									# only one decimal place is allowed, 
q11a_str = re.compile ("\$|[a-z]|%|@|\\|/|\?",re.I)						# 2nd part of q11 (not allow) Currency, or any other symbols
q12_str = re.compile ("0.02\*D7|D7\*0.02|0.02\*$D7|$D7\*0.02") 			# Formula variation
q13e8_str = re.compile ("0.02\*D8|D8\*0.02|0.02\*$D8|$D8\*0.02") 		# Formula variation
q13e9_str = re.compile ("0.02\*D9|D9\*0.02|0.02\*$D9|$D9\*0.02")		# Formula variation
q13e10_str = re.compile ("0.02\*D10|D10\*0.02|0.02\*$D10|$D10\*0.02")	# Formula variation
q14_str = re.compile ("\$.*\.00(\D|$)")									# must have currency, and two decimal values
q16_str = re.compile("sum\(E[567]:E1[01]\)",re.I)						# formula variation
q17_str = re.compile("\.000($|\D)",re.I)								# 3 decimal places
q17a_str = re.compile ("\$|[a-z]|%|@|\\|/|\?",re.I)						# 2nd part (not allow) Currency, or any other symbols
q18_str = re.compile ("\$F\$3\*B7|F\$3\*B7|B7\*\$F\$3|B7\*F\$3") 		# formula variation
q19f8_str = re.compile ("\$F\$3\*B8|F\$3\*B8|B8\*\$F\$3|B8\*F\$3") 		# formula variation
q19f9_str = re.compile ("\$F\$3\*B9|F\$3\*B9|B9\*\$F\$3|B9\*F\$3") 		# formula variation
q19f10_str = re.compile ("\$F\$3\*B10|F\$3\*B10|B10\*\$F\$3|B10\*F\$3") 	# formula variation
q20g7_str = re.compile ("(^=c7-f7$)|(^=\(c7-f7\)$)|(^=c7-\(B7\*\$F\$3\)$)|(^=c7-\(\$F\$3\*B7\)$)|(^=c7-B7\*\$F\$3$)|(^=c7-\$F\$3\*B7$)", re.I)				   # formula variation
q20g8_str = re.compile ("(^=c8-f8$)|(^=\(c8-f8\)$)|(^=c8-\(B8\*\$F\$3\)$)|(^=c8-\(\$F\$3\*B8\)$)|(^=c8-B8\*\$F\$3$)|(^=c8-\$F\$3\*B8$)", re.I)				   # formula variation
q20g9_str = re.compile ("(^=c9-f9$)|(^=\(c9-f9\)$)|(^=c9-\(B9\*\$F\$3\)$)|(^=c9-\(\$F\$3\*B9\)$)|(^=c9-B9\*\$F\$3$)|(^=c9-\$F\$3\*B9$)", re.I)				   # formula variation
q20g10_str = re.compile ("(^=c10-f10$)|(^=\(c10-f10\)$)|(^=c10-\(B10\*\$F\$3\)$)|(^=c10-\(\$F\$3\*B10\)$)|(^=c10-B10\*\$F\$3$)|(^=c10-\$F\$3\*B10$)", re.I)				   # formula variation
q21_str = re.compile ("average\(g[567]:g1[01]\)",re.I)					# formula variation

epsilon = 0.0000000000001												# ERROR MARGIN in Floating Point Calculations

optlist = []

# Process The File
def ProcessTheFile(xlApp, filepath, fh):
	global q2_str, q2a_str, q3_str, q5a1_str, q5e3_str, q5a5_str
	global q5b5_str, q5c5_str, q5d5_str, q5e5_str, q5f5_str, q5g5_str, q11_str, q11a_str
	global q10a7_str, q10a8_str, q10a9_str, q10a10_str
	global q12_str, q13e8_str, q13e9_str, q13e10_str, q14_str, q16_str, q17_str, q17a_str, q18_str, q19f8_str
	global q19f9_str, q19f10_str, q20g7_str, q20g8_str, q20g9_str, q20g10_str, q21_str
	
	dfilename = os.path.basename(filepath)					# Get the filename, for use with Excel
	xl.Caption(xlApp, "[ " + dfilename + " ]")						# Change the caption for MSExcel to provide visual feedback
	marks = {}											# initialise the Dictionary for student marks
	print "\n\n\n"
	print "##  ===================================  ##"
	print "##  Processing File: " + dfilename
	print "##                                       ##"
#	xl.OpenActivateFile(xlApp, filepath, UpdateLinks=0, ReadOnly=1, AddToMru=0) 	# Open the student submission in Excel
	xl.OpenActivateFile(xlApp, filepath, 0, 1, 0) 	# Open the student submission in Excel	
	uInfo={}		# initialise the Dictionary to store User Information(likewise blanking it out with each iteration)
	
	print "Q2a==>",
	marks['q2a'] = 0
	uInfo['studentID'] = xl.GetValue2 (xlApp, "a15")
	uInfo['LastName']  = xl.GetValue(xlApp, "A16")
	uInfo['FirstName'] = xl.GetValue(xlApp, "A17")
	if q2a_str.search(str(xl.GetValue2(xlApp, "A15"))):
		marks['q2a'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "StudentID: ", xl.GetValue2(xlApp, "A15")

	print "Q2b==>",
	marks['q2b'] = 0
	if q2_str.search(xl.GetValue(xlApp, "A16")) and \
   		q2_str.search(xl.GetValue(xlApp, "A17")) :
		print "TRUE ",
		marks['q2b'] = 1
	else:
		print "FALSE",
	print "Lastname: ", xl.GetValue(xlApp, "A16"),"\t",
	print "Firstname: ", xl.GetValue(xlApp, "A17")

	print "Q2c==>",
	marks['q2c'] = 0
	if q2_str.search(str(xl.GetValue(xlApp,"a18"))):
		print "TRUE ",
		marks['q2c'] = 1
	else:
		print "FALSE",
	print "School: ", xl.GetValue(xlApp,"a18")

	# Q3 Analyse
	print "Q3 ==>",
	marks['q3'] = 0
	if not q3_str.search(xl.GetNumberFormat(xlApp, "A15")):
		print "TRUE ",
		marks['q3'] = 1
	else:
		print "FALSE",

	print "Numb Format (no decimal places)? ", xl.GetNumberFormat(xlApp, "A15") 

	print "Q4 ==>",
	marks['q4'] = 0
	if os.path.isfile(filepath):
		marks['q4'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "File Exists ?", os.path.basename(filepath)
	
	print "Q5 ==>",
	marks['q5'] = 0
	if q5a1_str.search(xl.GetValue(xlApp, "A1")) and \
	   q5e3_str.search(xl.GetValue(xlApp, "E3")) and \
	   q5a5_str.search(xl.GetValue(xlApp, "a5")) and \
	   q5b5_str.search(xl.GetValue(xlApp, "b5")) and \
	   q5c5_str.search(xl.GetValue(xlApp, "c5")) and \
	   q5d5_str.search(xl.GetValue(xlApp, "d5")) and \
	   q5e5_str.search(xl.GetValue(xlApp, "e5")) and \
	   q5f5_str.search(xl.GetValue(xlApp, "f5")) and \
	   q5g5_str.search(xl.GetValue(xlApp, "g5")):
		marks['q5'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Labels as Expected",
	print "A1:", xl.GetValue(xlApp, "A1"), 
	print "E3:", xl.GetValue(xlApp, "E3"), 
	for ncol in ["A","B","C","D","E","F","G"]:
	    print ncol+"5:", xl.GetValue(xlApp, ncol+"5"),
	print 

	print "Q6 ==>",
	marks['q6'] = 0
	if xl.isBold (xlApp, "A1,A5:G5,E3"):
		marks['q6'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Labels Bold ? ", xl.isBold (xlApp, "A1,A5:G5,E3")

	print "Q7 ==>",
	marks['q7'] = 0	
	if xl.isAlignedLeft( xlApp, "A1,A5"):
		marks['q7'] = 1
		print "TRUE ",
	else:
	    print "FALSE",
	print  "Left Aligned ? ", xl.isAlignedLeft( xlApp, "A1,A5")

	print "Q8 ==>",
	marks['q8'] = 0
	if xl.isAlignedRight( xlApp, "B5:G5,E3"):
		marks['q8'] = 1
		print "TRUE ",
	else:
	    print "FALSE",
	print "Right Aligned ? ", xl.isAlignedRight( xlApp, "B5:G5,E3")
	
	print "Q9 ==>",
	marks['q9'] = 0
	if xl.GetFontName(xlApp, "A1,A5:G5,E4") == "Arial" and \
	   xl.GetFontName(xlApp, "A1,A5:G5,E4") == 10.0:
		marks['q9'] = 1
		print "TRUE ",
	else:
	    print "FALSE",
	print "Arial/10    ? 	", xl.GetFontName(xlApp, "A1,A5:G5,E4"), xl.GetFontName(xlApp, "A1,A5:G5,E4")

	print "Q10==>",
	marks['q10'] = 0
	if q10a7_str.search(xl.GetValue(xlApp, "A7")) and \
	   q10a8_str.search(xl.GetValue(xlApp, "A8")) and \
	   q10a9_str.search(xl.GetValue(xlApp, "A9")) and \
	   q10a10_str.search(xl.GetValue(xlApp, "A10")) and \
	   38.2 - epsilon <= xl.GetValue2(xlApp, "B7") <=  38.2 + epsilon and \
	   30.0 - epsilon <= xl.GetValue2(xlApp, "B8") <=  30.0 + epsilon and \
	   32.3 - epsilon <= xl.GetValue2(xlApp, "B9") <=  32.3 + epsilon and \
	   25.1 - epsilon <= xl.GetValue2(xlApp, "B10") <= 25.1 + epsilon and \
	   76.0 - epsilon <= xl.GetValue2(xlApp, "C7") <=  76.0 + epsilon and \
	   61.5 - epsilon <= xl.GetValue2(xlApp, "C8") <=  61.5 + epsilon and \
	   70.2 - epsilon <= xl.GetValue2(xlApp, "C9") <=  70.2 + epsilon and \
	   48.1 - epsilon <= xl.GetValue2(xlApp, "C10") <=  48.1 + epsilon and \
	   85.0 - epsilon <= xl.GetValue2(xlApp, "D7") <=  85.0 + epsilon and \
	   64.0 - epsilon <= xl.GetValue2(xlApp, "D8") <=  64.0 + epsilon and \
	   72.0 - epsilon <= xl.GetValue2(xlApp, "D9") <=  72.0 + epsilon and \
	   55.0 - epsilon <= xl.GetValue2(xlApp, "D10") <= 55.0 + epsilon :
		marks['q10'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Insert Value? "	
	for nrow in range(7,11):
		for ncol in ["A","B","C","D"]:
			print ncol+str(nrow)+":", xl.GetValue2(xlApp,ncol+str(nrow)),
		print

	print "Q11==>",
	marks['q11'] = 0
	if q11_str.search(xl.GetNumberFormat(xlApp, "B7:B10,C7:C10")) and \
		not q11a_str.search(xl.GetNumberFormat(xlApp, "B7:B10,C7:C10")):
		marks['q11'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Number Format (one decimal place)? ", xl.GetNumberFormat(xlApp, "B7:B10,C7:C10")

	print "Q12==>",
	marks['q12'] = 0
	if q12_str.search(xl.GetFormula( xlApp, "e7" )):
		marks['q12'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Formula 0.02*D7 ?", xl.GetFormula( xlApp, "e7" )

	print "Q13==>",
	marks['q13'] = 0
	if q13e8_str.search(xl.GetFormula( xlApp, "e8" ) ) and \
	   q13e9_str.search(xl.GetFormula( xlApp, "e9" )) and \
	   q13e10_str.search(xl.GetFormula( xlApp, "e10" )):
		marks['q13'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Formula filled down from above ?", 

	for nrow in range (8,11):
		print "E"+str(nrow)+": ", xl.GetFormula( xlApp,"E"+str(nrow)),
	print

	print "Q14==>",
	marks['q14'] = 0
	if q14_str.search(xl.GetNumberFormat(xlApp, "E7:E12")):
		marks['q14'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Number Format (currency, two decimal place)? ", xl.GetNumberFormat(xlApp, "E7:E12")

	print "Q15==>",
	marks['q15'] = 0
	if string.upper(xl.GetValue(xlApp, "D12")) == "TOTAL" and \
		string.upper(xl.GetValue(xlApp, "F12")) == "AVERAGE":
		marks['q15'] = 1
		print "TRUE ",
	else:
		print "FALSE",	
	print "Labels (Total, Average) ?",
	print  xl.GetValue(xlApp, "D12") , ",",
	print  xl.GetValue(xlApp, "F12")

	print "Q16==>",
	marks['q16'] = 0
	if q16_str.search(xl.GetFormula(xlApp, "e12")):
		marks['q16'] = 1
		print "TRUE ",
	else:
		print "FALSE",	

	print "Formula sum(e7:e10)    ? ",
	print  xl.GetFormula(xlApp, "e12")

	print "Q17==>",
	marks['q17'] = 0
	if q17_str.search(xl.GetNumberFormat(xlApp, "F3")) and \
	   not q17a_str.search(xl.GetNumberFormat(xlApp, "F3")) and \
	   xl.GetValue2(xlApp, "F3") == 2.019:
		marks['q17'] = 1
		print "TRUE ",
	else:
		print "FALSE",	
	print "value 2.019, and number with three decimal places ?",
	print  xl.GetValue2(xlApp, "F3"), ",",
	print  xl.GetNumberFormat(xlApp, "F3")

	print "Q18==>",
	marks['q18'] = 0
	if q18_str.search(xl.GetFormula(xlApp,"f7")):
		marks['q18'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Formula $F$3*B7 or F$3*B7 ?", xl.GetFormula(xlApp,"f7")

	print "Q19==>",
	marks['q19'] = 0
	if q19f8_str.search(xl.GetFormula(xlApp,"f8")) and \
		q19f9_str.search(xl.GetFormula(xlApp,"f9")) and \
		q19f10_str.search(xl.GetFormula(xlApp,"f10")):
		marks['q19'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Filled Formula down ?",	
	for nrow in range (7,11):
		print "F"+str(nrow)+":",xl.GetFormula(xlApp, "F"+str(nrow)),
	print

	print "Q20==>",
	marks['q20'] = 0
	if  q20g7_str.search(xl.GetFormula(xlApp,"g7")) and \
		q20g8_str.search(xl.GetFormula(xlApp,"g8")) and \
		q20g9_str.search(xl.GetFormula(xlApp,"g9")) and \
		q20g10_str.search(xl.GetFormula(xlApp,"g10")):
		marks['q20'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Formula c7-f7 filled down ?",	
	for nrow in range (7,11):
	    print "G"+str(nrow)+ ":",xl.GetFormula(xlApp,"G"+str(nrow)),
	print   

	print "Q21==>",
	marks['q21'] = 0
	if q21_str.search(xl.GetFormula(xlApp,"g12"))  :
		marks['q21'] = 1
		print "TRUE ",
	else:
		print "FALSE",
	print "Formula AVERAGE(g7:g10) ?",	
	print xl.GetFormula(xlApp, "g12") 
	
	studscore = 0
	for key in marks.keys():
		studscore = studscore + marks[key]

	# Basic Document Information Extracted from the File:
	# - this information is recorded along with the OS information

	uInfo['xl Author']= xl.docInfo (xlApp, dfilename, 'Author') 
	uInfo['xl Last Author'] = xl.docInfo (xlApp, dfilename, 'Last Author')
	uInfo['xl Creation Date'] = xl.docInfo (xlApp, dfilename, 'Creation Date')
	uInfo['xl Last Save Time'] = xl.docInfo (xlApp, dfilename, 'Last Save Time')
	uInfo['os File Time'] = time.asctime(time.localtime(os.path.getmtime(filepath)))
	# print "Total Edit Tm: ", xl.docInfo (xlApp, dfilename, 'Total Editing Time')
	
	xl.docClose (xlApp, dfilename, 0)	
	
	#
	# OutPut a summary of the information gathered above, into a data file for easy extraction
	# into a spreadsheet or database
	# -- redirect stdout (so I can use the print command rather than write)
	#    doing this lets the more complex 'print' provide the conversion of expressoin
	#    to a string for output, otherwise I would have to write a routine for converting
	#    the output data to 'string' before I could use write.
	cons_stdout = sys.__stdout__
	sys.stdout = fh
	sep = '\t'
	print uInfo['studentID'], sep,uInfo['LastName'], sep,uInfo['FirstName'],
	print sep,marks['q2a'], sep,marks['q2b'], sep,marks['q2c'], sep,marks['q3'],sep,marks['q4'],
	print sep,marks['q5'],sep,marks['q6'],sep,marks['q7'],sep,marks['q8'],
	print sep,marks['q9'],sep,marks['q10'],sep,marks['q11'],sep,marks['q12'],sep,marks['q13'],sep,marks['q14'],
	print sep,marks['q15'],sep,marks['q16'],sep,marks['q17'],sep,marks['q18'],sep,marks['q19'],sep,marks['q20'],
	print sep,marks['q21'],
	print sep,dfilename, sep, os.path.basename(os.path.dirname(filepath)),
	print sep,uInfo['xl Creation Date'], sep, uInfo['xl Last Save Time'],  sep, uInfo['os File Time'],
	print sep,uInfo['xl Author'], sep,uInfo['xl Last Author']

	# -- return the stdout to the console	
	sys.stdout = cons_stdout	
	print ""
	print "______________________________"
	print "Student Score is: ", studscore, "\t:["+ str(uInfo['studentID'])+"]\t:", uInfo['LastName'],uInfo['FirstName']
	print "------------------------------"

def cmdlineoptions():
	import getopt
	try:
		optlist, args = getopt.getopt(sys.argv[1:], 'f:d:p:o:')
	except getopt.GetoptError:
#    except:
		# print help information and exit:
		usage()
		sys.exit(2)
		
	if optlist==[]:
		usage()
		sys.exit(2)
		
	return optlist

def usage():
	progname = os.path.basename(sys.argv[0])

	print """
	Usage: %s [ -d directory [-p pattern] | -f filename ] [ -o outfile ]
	
	-d directory  the name of the directory to be analysed (including subdirectories)
	                  default(.)
	-p pattern    when used with -d specifies the file pattern to analyse
	                  default(*.xl?;*.wk?)
	-f filename    the name of the file to be analysed
	-o outfile      output file for recording summary information (good for use in data-analysis)
	
	example: %s -d submissions -p *.xl?;*.wk?
	         %s -d submissions
	         %s -f charlie.xls

	%s is a program developed to analyse (mark) student submissions for the TSC Cat 2
	spreadsheet exercise (2001.) This program requires Microsoft Excel and may be a
	useful tutorial in getting data from Microsoft Excel using Python
	""" % (progname, progname, progname, progname, progname)
	
def cmdlineprocess(optlist):
	searchdir = None
	filename = None
	dirpattern = "*.xl?;*.wk?"
	progname, extension = os.path.splitext(sys.argv[0])
	outfile = os.path.basename(progname) + ".txt"
	for optitem in optlist:
		if optitem[1][1:1] == "-":
			usage()
			sys.exit(2)
		elif optitem[0] == "-d":
			searchdir = 1
			if optitem[1] <> "":
				dir2search = optitem[1]
			else:
				dir2search = "."
		elif optitem[0] == "-p":
			if optitem[1] <> "":
				dirpattern = optitem[1]
			else:
				usage()
				sys.exit(2)
		elif optitem[0] == "-f":
			if optitem[1] <> "":
				filename = optitem[1]
			else:
				usage()
				sys.exit(2)
		elif optitem[0] == "-o":
			if optitem[1]<>"":
				outfile = optitem[1]
		else:
			pass

	xlApp, xlAlreadyRunning = xl.initExcel(1)
	fh = initLogFile(outfile)
	if searchdir:
		files = dirWalk.dirWalk(os.path.abspath(dir2search),1,dirpattern,1)
		for file in files:
			ProcessTheFile(xlApp, file, fh)
	elif filename:
		ProcessTheFile(xlApp, os.path.abspath(filename), fh)
	else:
		pass
		# usage()
		# sys.exit(2)
	xl.closeExcel(xlApp, xlAlreadyRunning)

# Open the file where data log of reports will be sent
# Format: Tab-delimited
#			Identifying Columns 1st,
#			Marks Details 2nd
#			Document Information 3rd
def initLogFile(outfile):
	fh = open(outfile,'w')
	sep = "\t"
	fh.write(	'studentID\tLastName\tFirstName\tq2a\tq2b\tq2c\tq3\tq4')
	fh.write('\tq5\tq6\tq7\tq8\tq9\tq10\tq11\tq12\tq13\tq14')
	fh.write('\tq15\tq16\tq17\tq18\tq19\tq20\tq21')
	fh.write('\tfilename\tdirectory')
	fh.write('\txl Creation Date\txl Last Save Time\tos File Time\txl Author\txl Last Author')
	fh.write('\n')
	return fh
	
if __name__ == "__main__":
	optlist = cmdlineoptions()
	cmdlineprocess(optlist)

